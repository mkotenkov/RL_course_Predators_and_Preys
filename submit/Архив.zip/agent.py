import torch
from dataclasses import dataclass

# === from DQN import DQN =========================================================================
import copy
import random
from collections import deque, namedtuple

import torch
import torch.nn as nn


Transition = namedtuple('Transition',
                        ('state', 'action', 'next_state', 'reward', 'done'))


class InnerModel(nn.Module):
    def __init__(self, global_config, n_neurons_to_process_bonus=16):
        super().__init__()        
        self.n_masks = global_config.n_masks
        self.n_actions = global_config.n_actions
        self.n_predators = global_config.n_predators  
        self.map_size = global_config.map_size     

        self.backbone = nn.ModuleList([
            nn.Conv2d(self.n_masks, 4, kernel_size=5, padding=2, stride=1),
            nn.LeakyReLU(),
            nn.Conv2d(4, 4, kernel_size=1, padding=0, stride=1),
            nn.MaxPool2d(2),
            nn.LeakyReLU(),
            nn.Conv2d(4, 6, kernel_size=3, padding=1, stride=1),
            nn.MaxPool2d(2),
            nn.LeakyReLU(),
            nn.Conv2d(6, 6, kernel_size=1, padding=0, stride=1),
            nn.LeakyReLU(),
            nn.Conv2d(6, 1, kernel_size=3, padding=1, stride=1),
            nn.LeakyReLU(),
            nn.MaxPool2d(2)
        ])

        self.backbone_3x3 = nn.ModuleList([
            nn.Conv2d(self.n_masks, 32, kernel_size=3, padding=0, stride=1),
            nn.LeakyReLU(),
        ])

        self.backbone_5x5 = nn.ModuleList([
            nn.Conv2d(self.n_masks, 32, kernel_size=5, padding=0, stride=1),
            nn.LeakyReLU(),
        ])

        self.backbone_9x9 = nn.ModuleList([
            nn.Conv2d(self.n_masks, 16, kernel_size=5, padding=0, stride=1),
            nn.LeakyReLU(),
            nn.Conv2d(16, 32, kernel_size=5, padding=0, stride=1),
            nn.LeakyReLU(),
        ])

        self.backbone_17x17 = nn.ModuleList([
            nn.Conv2d(self.n_masks, 4, kernel_size=5, padding=0, stride=1),
            nn.LeakyReLU(),
            nn.Conv2d(4, 8, kernel_size=5, padding=0, stride=1),
            nn.LeakyReLU(),
            nn.Conv2d(8, 16, kernel_size=5, padding=0, stride=1),
            nn.LeakyReLU(),
            nn.Conv2d(16, 32, kernel_size=5, padding=0, stride=1),
            nn.LeakyReLU(),
        ])

        self.bonus_count_processor = nn.Sequential(
            nn.Linear(1, n_neurons_to_process_bonus),
            nn.ReLU()
        )

        self.head = nn.Linear(40 * 40 // 2**6 + n_neurons_to_process_bonus + 128, self.n_actions)

    def forward(self, processed_state):        
        state, bonus_counts = processed_state
        state_3x3 = self.get_cut_from_processed_state(state, cut_size=3)
        state_5x5 = self.get_cut_from_processed_state(state, cut_size=5) 
        state_9x9 = self.get_cut_from_processed_state(state, cut_size=9) 
        state_17x17 = self.get_cut_from_processed_state(state, cut_size=17) 

        for module in self.backbone:
            state = module(state)

        for module in self.backbone_3x3:
            state_3x3 = module(state_3x3)        

        for module in self.backbone_5x5:
            state_5x5 = module(state_5x5)

        for module in self.backbone_9x9:
            state_9x9 = module(state_9x9)

        for module in self.backbone_17x17:
            state_17x17 = module(state_17x17)                  
        
        features_main = torch.flatten(state, start_dim=1)
        features_3x3 = torch.flatten(state_3x3, start_dim=1)
        features_5x5 = torch.flatten(state_5x5, start_dim=1)
        features_9x9 = torch.flatten(state_9x9, start_dim=1)
        features_17x17 = torch.flatten(state_17x17, start_dim=1)        
        bonus_features = self.bonus_count_processor(bonus_counts.resize(self.n_predators, 1))        

        x = torch.cat((features_main, features_3x3, features_5x5, features_9x9, features_17x17, bonus_features), dim=1)        
        x = self.head(x)        
        return x
    
    def get_cut_from_processed_state(self, processed_state, cut_size):
        start = self.map_size // 2 - cut_size // 2        
        end = start + cut_size

        return processed_state[..., start:end, start:end]


class DQN(nn.Module):
    def __init__(self, global_config, train_config):
        self.global_config = global_config
        self.train_config = train_config

        self.n_masks = global_config.n_masks
        self.n_actions = global_config.n_actions
        self.n_predators = global_config.n_predators
        self.map_size = global_config.map_size
        self.device = global_config.device

        self.learning_rate = train_config.learning_rate
        self.buffer_size = train_config.buffer_size
        self.gamma = train_config.gamma
        self.batch_size = train_config.batch_size
        self.tau = train_config.tau

        super().__init__()

        self.dqn = InnerModel(global_config)
        self.target_dqn = copy.deepcopy(self.dqn)
        
        self.buffer = deque(maxlen=self.buffer_size)
        self.criterion = nn.SmoothL1Loss()
        self.optimizer = torch.optim.AdamW(self.dqn.parameters(), lr=self.learning_rate, amsgrad=True)
        self.q_values = None  # used for display in gif

    def get_actions(self, processed_state, random=False):
        if random:
            return torch.randint(0, self.n_actions, (self.n_predators,))
        else:
            # expects unbatched input: [self.n_predators, self.n_masks, self.map_size, self.map_size]
            with torch.no_grad():
                # [self.n_predators, self.n_actions]
                self.q_values = self.dqn((torch.FloatTensor(processed_state[0]), torch.FloatTensor(processed_state[1])))
                return self.q_values.argmax(dim=1)

    def consume_transition(self, *args):
        self.buffer.append(Transition(*args))

    def sample_batch(self):
        processed_state = (torch.empty(self.batch_size, self.n_predators, self.n_masks,
                                       self.map_size, self.map_size, device=self.device, dtype=torch.float32),
                           torch.empty(self.batch_size, self.n_predators, device=self.device, dtype=torch.float32))
        actions = torch.empty(self.batch_size, self.n_predators, device=self.device, dtype=torch.int32)
        next_processed_state = (torch.empty(self.batch_size, self.n_predators, self.n_masks,
                                            self.map_size, self.map_size, device=self.device, dtype=torch.float32),
                                torch.empty(self.batch_size, self.n_predators, device=self.device, dtype=torch.float32))
        reward = torch.empty(self.batch_size, self.n_predators, device=self.device, dtype=torch.float32)
        done = torch.empty(self.batch_size, device=self.device, dtype=torch.bool)

        for i, t in enumerate(random.sample(self.buffer, self.batch_size)):
            processed_state[0][i] = torch.from_numpy(t.state[0])
            processed_state[1][i] = torch.from_numpy(t.state[1])
            actions[i] = torch.tensor(t.action, device=self.device, dtype=torch.int32)
            next_processed_state[0][i] = torch.from_numpy(t.next_state[0])
            next_processed_state[1][i] = torch.from_numpy(t.next_state[1])
            reward[i] = torch.tensor(t.reward, device=self.device, dtype=torch.float32)
            done[i] = t.done

        return processed_state, actions, next_processed_state, reward, done

    def update_policy_network(self):
        # processed_state: (
        # [BATCH_SIZE, self.n_predators, self.n_masks, self.map_size, self.map_size],  - masks
        # [BATCH_SIZE, self.n_predators]  - bonus info
        # )
        processed_state, actions, next_processed_state, reward, done = self.sample_batch()

        q_values = []
        for i in range(self.batch_size):
            # [self.n_predators, self.n_actions] for all actions
            preds = self.dqn((processed_state[0][i], processed_state[1][i]))
            q_values.append(preds[torch.arange(self.n_predators), actions[i]])
        # [BATCH_SIZE, self.n_predators] for taken actions
        q_values = torch.stack(q_values)

        target_q_values = []
        with torch.no_grad():
            for i in range(self.batch_size):
                # [self.n_predators, self.n_actions] for all actions
                preds = self.target_dqn((next_processed_state[0][i], next_processed_state[1][i]))
                future_q_values = preds.max(dim=1).values if not done[i] else torch.zeros(self.n_predators)
                target_q_values.append(reward[i] + self.gamma * future_q_values)
        # [BATCH_SIZE, self.n_predators]
        target_q_values = torch.stack(target_q_values)

        loss = self.criterion(q_values, target_q_values)
        self.optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_value_(self.dqn.parameters(), 50)
        self.optimizer.step()

        return loss.item()

    def soft_update_target_network(self):
        target_net_state_dict = self.target_dqn.state_dict()
        policy_net_state_dict = self.dqn.state_dict()
        for key in policy_net_state_dict:
            target_net_state_dict[key] = policy_net_state_dict[key] * \
                self.tau + target_net_state_dict[key]*(1-self.tau)
        self.target_dqn.load_state_dict(target_net_state_dict)

    def save(self, path):
        torch.save(self.state_dict(), path)

    def load(self, path):
        self.load_state_dict(torch.load(path))

# === from preprocess import preprocess ===========================================================
from queue import Queue
import numpy as np

def get_bonus_counts(info):
    return np.array([p['bonus_count'] for p in info['predators']])


def get_adjacent_cells(x, y, obstacles_mask, distance_mask):
    """Yields adjacent cells to (x, y) that are not obstacles and have not been visited"""
    n, m = obstacles_mask.shape
    for dx, dy in [(0, 1), (0, -1), (1, 0), (-1, 0)]:
        nx = (x + dx) % m if x + dx >= 0 else m - 1
        ny = (y + dy) % n if y + dy >= 0 else n - 1
        if obstacles_mask[ny, nx] != 1 and np.isnan(distance_mask[ny, nx]):
            yield (nx, ny)


def get_distance_mask(centered_obstacles_mask, source=(20, 20)):
    queue = Queue()
    queue.put(source)

    distance_mask = np.empty_like(centered_obstacles_mask, dtype=np.float32)
    distance_mask.fill(np.nan)
    distance_mask[source[1], source[0]] = 0

    while not queue.empty():
        x, y = queue.get()

        for nx, ny in get_adjacent_cells(x, y, centered_obstacles_mask, distance_mask):
            queue.put((nx, ny))
            distance_mask[ny, nx] = distance_mask[y, x] + 1

    distance_mask[np.isnan(distance_mask)] = -1
    distance_mask = distance_mask / distance_mask.max()
    distance_mask[distance_mask < 0] = 2
    return distance_mask


def preprocess(state, info):
    num_teams = info['preys'][0]['team']

    stones_mask = np.logical_and(state[:, :, 0] == -1, state[:, :, 1] == -1)
    preys_mask = (state[:, :, 0] == num_teams).astype(np.float64)
    enemies_mask = np.logical_and(state[:, :, 0] > 0, state[:, :, 0] < num_teams).astype(np.float64)
    bonuses_mask = np.logical_and(state[:, :, 0] == -1, state[:, :, 1] == 1).astype(np.float64)
    teammates_mask = state[:, :, 0] == 0
    obstacles_mask = np.logical_or(stones_mask, teammates_mask).astype(np.float64)

    coords = [(predator['x'], predator['y']) for predator in info['predators']]

    n, m, _ = state.shape
    vertical_center = n // 2
    horizontal_center = m // 2

    output = []
    for x, y in coords:
        bias = (horizontal_center - x, vertical_center - y)

        centered_obstacles_mask = np.roll(obstacles_mask, bias, axis=(1, 0))
        distance_mask = get_distance_mask(centered_obstacles_mask)

        output.append(np.stack([
            centered_obstacles_mask,
            np.roll(preys_mask, bias, axis=(1, 0)),
            np.roll(enemies_mask, bias, axis=(1, 0)),            
            np.roll(bonuses_mask, bias, axis=(1, 0)),
            distance_mask
        ]))

    bonus_counts = get_bonus_counts(info)    

    return np.stack(output), bonus_counts

# =================================================================================================

@dataclass
class GlobalConfig:
    device: str
    n_actions: int
    n_predators: int
    n_masks: int
    map_size: int


@dataclass
class TrainConfig:
    description: str
    max_steps_for_episode: int
    gamma: float
    initial_steps: int
    steps: int
    steps_per_update: int
    steps_per_paint: int
    steps_per_eval: int
    buffer_size: int
    batch_size: int
    learning_rate: float
    eps_start: float
    eps_end: float
    eps_decay: int
    tau: float
    reward_params: dict
    seed: int

    def __str__(self):
        return '\n'.join([f'{k}: {v}' for k, v in vars(self).items()])


global_config = GlobalConfig(
    device='cuda' if torch.cuda.is_available() else 'cpu',
    n_actions=5,
    n_predators=5,
    n_masks=5,
    map_size=40
)

train_config = TrainConfig(
    description='inference...',
    max_steps_for_episode=300,
    gamma=0.9,
    initial_steps=300,  # 3000
    steps=100_000,
    steps_per_update=3,
    steps_per_paint=250,  # 500
    steps_per_eval=1000,  # 5000
    buffer_size=10_000,
    batch_size=64,
    learning_rate=0.001,
    eps_start=0.9,
    eps_end=0.05,
    eps_decay=1000,
    tau=0.005,  # the update rate of the target network, was 0.005
    reward_params=dict(
        w_dist_change=-0.5,
        w_kill_prey=1.,
        w_kill_enemy=3.,
        w_kill_bonus=1.3,
        standing_still_penalty=-0.7,
        gamma_for_bonus_count=0.5,
        n_nearest_targets=2,
    ),
    seed=1234
)

class Agent:
    def get_actions(self, state, info):
        processed_state = preprocess(state, info)
        actions = self.model.get_actions(processed_state)
        return actions

    def reset(self, state, info):
        self.model = DQN(global_config, train_config)
        self.model.load(__file__[:-8] + '/model_weights.pt')